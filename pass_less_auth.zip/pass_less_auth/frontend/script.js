// Register a new user
async function registerUser() {
    const email = document.getElementById('register-email').value;
    const phone = document.getElementById('register-phone').value;
    const cpr = document.getElementById('register-cpr').value;
    const answer1 = document.getElementById('register-answer1').value;
    const answer2 = document.getElementById('register-answer2').value;
    const feedback = document.getElementById('register-feedback');

    if (!email || !phone || !cpr || !answer1 || !answer2) {
        showFeedback(feedback, 'Please fill in all fields', 'danger');
        return;
    }

    showFeedback(feedback, 'Registering...', 'info');

    try {
        const response = await fetch('http://localhost:8000/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, phone, cpr, answer1, answer2 })
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.detail || 'Registration failed');
        }

        showFeedback(feedback, 'Registration successful! Verify your email using the link in the server console.', 'success');
    } catch (err) {
        showFeedback(feedback, err.message, 'danger');
    }
}

// Start the login process
async function startLogin() {
    const cpr = document.getElementById('login-cpr').value;
    const method = document.getElementById('login-method').value;
    const feedback = document.getElementById('login-feedback');

    if (!cpr) {
        showFeedback(feedback, 'Please enter your CPR Number', 'danger');
        return;
    }

    showFeedback(feedback, 'Initiating login...', 'info');

    try {
        // Initiate login
        const response = await fetch('http://localhost:8000/login/initiate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cpr, method })
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.detail || 'Failed to initiate login');
        }

        if (method === 'magic_link') {
            showFeedback(feedback, 'Magic link sent to your email. Check the server console and click the link.', 'info');
        } else if (method === 'otp_sms') {
            showFeedback(feedback, 'OTP sent to your phone. Check the server console, then enter the OTP.', 'info');
            const otp = prompt('Enter the OTP from the server console:');
            if (otp) {
                await verifyLogin(cpr, method, { otp }, feedback);
            } else {
                throw new Error('OTP is required');
            }
        } else if (method === 'security_questions') {
            showFeedback(feedback, 'Answer your security questions.', 'info');
            const answer1 = prompt('What is your favorite color?');
            const answer2 = prompt("What is your pet's name?");
            if (answer1 && answer2) {
                await verifyLogin(cpr, method, { answer1, answer2 }, feedback);
            } else {
                throw new Error('Answers are required');
            }
        }
    } catch (err) {
        showFeedback(feedback, err.message, 'danger');
    }
}

// Verify login based on method
async function verifyLogin(cpr, method, data, feedback) {
    showFeedback(feedback, 'Verifying...', 'info');
    const response = await fetch('http://localhost:8000/login/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cpr, method, data })
    });

    const result = await response.json();
    if (!response.ok) {
        throw new Error(result.detail || 'Verification failed');
    }

    showFeedback(feedback, 'Login successful! Redirecting...', 'success');
    localStorage.setItem('token', result.access_token);
    setTimeout(() => window.location.href = 'dashboard.html', 1000);
}

// Display feedback messages
function showFeedback(feedbackElement, message, type) {
    feedbackElement.textContent = message;
    feedbackElement.className = `alert alert-${type}`;
    feedbackElement.classList.remove('d-none');
}