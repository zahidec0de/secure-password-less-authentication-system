from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User
import jwt
import random
from datetime import datetime, timedelta
import bcrypt
import re
from app.config import SECRET_KEY, ALGORITHM  # Import from config

otp_storage = {}
magic_link_storage = {}

class AuthService:
    def __init__(self):
        pass

    def hash_answer(self, answer: str) -> str:
        return bcrypt.hashpw(answer.lower().encode(), bcrypt.gensalt()).decode()

    def verify_answer(self, answer: str, hashed_answer: str) -> bool:
        return bcrypt.checkpw(answer.lower().encode(), hashed_answer.encode())

    def validate_email(self, email: str) -> bool:
        return bool(re.match(r"[^@]+@[^@]+\.[^@]+", email))

    def validate_phone(self, phone: str) -> bool:
        return bool(re.match(r"^[0-9]+$", phone))

    async def register_user(self, email: str, phone: str, cpr: str, answer1: str, answer2: str, db: Session):
        if not self.validate_email(email):
            raise HTTPException(status_code=400, detail="Invalid email format")
        if not self.validate_phone(phone):
            raise HTTPException(status_code=400, detail="Invalid phone number format")
        if len(answer1) < 3 or len(answer2) < 3:
            raise HTTPException(status_code=400, detail="Security answers must be at least 3 characters")

        if db.query(User).filter(User.email == email).first():
            raise HTTPException(status_code=400, detail="Email already registered")
        if db.query(User).filter(User.phone == phone).first():
            raise HTTPException(status_code=400, detail="Phone number already registered")
        if db.query(User).filter(User.cpr == cpr).first():
            raise HTTPException(status_code=400, detail="CPR already registered")

        hashed_answer1 = self.hash_answer(answer1)
        hashed_answer2 = self.hash_answer(answer2)

        user = User(email=email, phone=phone, cpr=cpr, security_answer1=hashed_answer1, security_answer2=hashed_answer2)
        db.add(user)
        db.commit()
        db.refresh(user)

        verification_token = jwt.encode(
            {"user_id": user.id, "exp": datetime.utcnow() + timedelta(minutes=5)},
            SECRET_KEY,
            algorithm=ALGORITHM
        )
        verification_url = f"http://localhost:8000/verify-email?token={verification_token}"
        print(f"[{datetime.utcnow()}] Verification email for {email}: {verification_url}")
        return {"user_id": user.id}

    async def verify_email(self, token: str, db: Session):
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            user_id = payload["user_id"]
            user = db.query(User).filter(User.id == user_id).first()
            if not user:
                raise HTTPException(status_code=404, detail="User not found")
            print(f"[{datetime.utcnow()}] Email verified for user {user_id}")
            return {"message": "Email verified successfully"}
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Verification link expired")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid verification link")

    async def initiate_login(self, cpr: str, method: str, db: Session):
        user = db.query(User).filter(User.cpr == cpr).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if method == "magic_link":
            token = jwt.encode(
                {"user_id": user.id, "exp": datetime.utcnow() + timedelta(minutes=5)},
                SECRET_KEY,
                algorithm=ALGORITHM
            )
            print(f"[auth.py] Generated magic link token: {token}")
            magic_link_storage[cpr] = {"token": token, "expires": datetime.utcnow() + timedelta(minutes=5)}
            magic_url = f"http://localhost:8000/login/magic?token={token}"  # Removed URL encoding
            print(f"[{datetime.utcnow()}] Magic link for {user.email}: {magic_url}")
            return {"message": "Magic link sent to your email. Check the server console."}
        
        elif method == "otp_sms":
            otp = f"{random.randint(100000, 999999):06d}"
            otp_storage[cpr] = {"otp": otp, "expires": datetime.utcnow() + timedelta(minutes=5)}
            print(f"[{datetime.utcnow()}] OTP SMS for {user.phone}: {otp}")
            return {"message": "OTP sent to your phone. Check the server console."}
        
        elif method == "security_questions":
            return {"message": "Answer your security questions to log in."}
        
        else:
            raise HTTPException(status_code=400, detail="Invalid login method")

    async def verify_login(self, cpr: str, method: str, data: dict, db: Session):
        user = db.query(User).filter(User.cpr == cpr).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if method == "magic_link":
            token = data.get("token")
            print(f"[auth.py] Verifying token for CPR {cpr}: {token}")
            if cpr not in magic_link_storage:
                raise HTTPException(status_code=400, detail="Magic link not found or expired")
            stored_token = magic_link_storage[cpr]
            if datetime.utcnow() > stored_token["expires"]:
                del magic_link_storage[cpr]
                raise HTTPException(status_code=400, detail="Magic link expired")
            if token != stored_token["token"]:
                print(f"[auth.py] Token mismatch - Stored: {stored_token['token']}, Provided: {token}")
                raise HTTPException(status_code=401, detail="Invalid magic link")
            del magic_link_storage[cpr]

        elif method == "otp_sms":
            otp = data.get("otp")
            if cpr not in otp_storage:
                raise HTTPException(status_code=400, detail="OTP not found or expired")
            stored_otp = otp_storage[cpr]
            if datetime.utcnow() > stored_otp["expires"]:
                del otp_storage[cpr]
                raise HTTPException(status_code=400, detail="OTP expired")
            if otp != stored_otp["otp"]:
                raise HTTPException(status_code=401, detail="Invalid OTP")
            del otp_storage[cpr]

        elif method == "security_questions":
            answer1 = data.get("answer1")
            answer2 = data.get("answer2")
            if not self.verify_answer(answer1, user.security_answer1) or not self.verify_answer(answer2, user.security_answer2):
                raise HTTPException(status_code=401, detail="Incorrect answers to security questions")

        else:
            raise HTTPException(status_code=400, detail="Invalid login method")

        payload = {
            "sub": str(user.id),
            "exp": datetime.utcnow() + timedelta(minutes=15)
        }
        token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
        
        print(f"[{datetime.utcnow()}] Login successful for user with CPR {cpr} via {method}")
        return {"access_token": token, "token_type": "bearer"}