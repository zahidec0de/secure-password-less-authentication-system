from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.auth import AuthService
from app.database import get_db, Base, engine
from pydantic import BaseModel
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import jwt
from app.config import SECRET_KEY, ALGORITHM  # Import from config

from app import models

app = FastAPI()
auth_service = AuthService()

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("Creating database tables...")
Base.metadata.create_all(bind=engine, checkfirst=True)
print("Database tables created.")

class RegisterRequest(BaseModel):
    email: str
    phone: str
    cpr: str
    answer1: str
    answer2: str

class LoginInitiateRequest(BaseModel):
    cpr: str
    method: str

class LoginVerifyRequest(BaseModel):
    cpr: str
    method: str
    data: dict

@app.post("/register")
@limiter.limit("5/minute")
async def register(request: Request, register_request: RegisterRequest, db: Session = Depends(get_db)):
    return await auth_service.register_user(
        register_request.email,
        register_request.phone,
        register_request.cpr,
        register_request.answer1,
        register_request.answer2,
        db
    )

@app.get("/verify-email")
async def verify_email(token: str, db: Session = Depends(get_db)):
    return await auth_service.verify_email(token, db)

@app.post("/login/initiate")
@limiter.limit("5/minute")
async def initiate_login(request: Request, login_request: LoginInitiateRequest, db: Session = Depends(get_db)):
    return await auth_service.initiate_login(login_request.cpr, login_request.method, db)

@app.post("/login/verify")
@limiter.limit("5/minute")
async def verify_login(request: Request, verify_request: LoginVerifyRequest, db: Session = Depends(get_db)):
    return await auth_service.verify_login(verify_request.cpr, verify_request.method, verify_request.data, db)

@app.get("/login/magic")
async def verify_magic_link(token: str, db: Session = Depends(get_db)):
    print(f"[main.py] Received token: {token}")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload["user_id"]
        print(f"[main.py] Decoded user_id: {user_id}")
        user = db.query(models.User).filter(models.User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        cpr = user.cpr
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Magic link expired")
    except jwt.InvalidTokenError as e:
        print(f"[main.py] Invalid token error: {str(e)}")
        raise HTTPException(status_code=401, detail="Invalid magic link")

    verify_request = LoginVerifyRequest(
        cpr=cpr,
        method="magic_link",
        data={"token": token}
    )
    await auth_service.verify_login(verify_request.cpr, verify_request.method, verify_request.data, db)
    return RedirectResponse(url="http://localhost:8001/dashboard.html")